--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

-- Started on 2025-07-15 20:50:23

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 220 (class 1259 OID 16410)
-- Name: appointments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appointments (
    appointment_id integer NOT NULL,
    student_name character varying(100) NOT NULL,
    counselor_id integer NOT NULL,
    appointment_date date NOT NULL,
    appointment_time time without time zone NOT NULL,
    status character varying(20) NOT NULL
);


ALTER TABLE public.appointments OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 16409)
-- Name: appointments_appointment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.appointments_appointment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.appointments_appointment_id_seq OWNER TO postgres;

--
-- TOC entry 4816 (class 0 OID 0)
-- Dependencies: 219
-- Name: appointments_appointment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.appointments_appointment_id_seq OWNED BY public.appointments.appointment_id;


--
-- TOC entry 218 (class 1259 OID 16401)
-- Name: counselors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.counselors (
    counselor_id integer NOT NULL,
    name character varying(100) NOT NULL,
    specialization character varying(100) NOT NULL,
    availability text NOT NULL
);


ALTER TABLE public.counselors OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 16400)
-- Name: counselors_counselor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.counselors_counselor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.counselors_counselor_id_seq OWNER TO postgres;

--
-- TOC entry 4817 (class 0 OID 0)
-- Dependencies: 217
-- Name: counselors_counselor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.counselors_counselor_id_seq OWNED BY public.counselors.counselor_id;


--
-- TOC entry 222 (class 1259 OID 16422)
-- Name: feedback; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feedback (
    feedback_id integer NOT NULL,
    student_name character varying(100) NOT NULL,
    counselor_id integer NOT NULL,
    rating integer NOT NULL,
    comments text,
    CONSTRAINT feedback_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


ALTER TABLE public.feedback OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 16421)
-- Name: feedback_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.feedback_feedback_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.feedback_feedback_id_seq OWNER TO postgres;

--
-- TOC entry 4818 (class 0 OID 0)
-- Dependencies: 221
-- Name: feedback_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.feedback_feedback_id_seq OWNED BY public.feedback.feedback_id;


--
-- TOC entry 4649 (class 2604 OID 16413)
-- Name: appointments appointment_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments ALTER COLUMN appointment_id SET DEFAULT nextval('public.appointments_appointment_id_seq'::regclass);


--
-- TOC entry 4648 (class 2604 OID 16404)
-- Name: counselors counselor_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.counselors ALTER COLUMN counselor_id SET DEFAULT nextval('public.counselors_counselor_id_seq'::regclass);


--
-- TOC entry 4650 (class 2604 OID 16425)
-- Name: feedback feedback_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feedback ALTER COLUMN feedback_id SET DEFAULT nextval('public.feedback_feedback_id_seq'::regclass);


--
-- TOC entry 4808 (class 0 OID 16410)
-- Dependencies: 220
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.appointments (appointment_id, student_name, counselor_id, appointment_date, appointment_time, status) FROM stdin;
1	Alice Johnson	1	2025-07-20	10:00:00	Scheduled
2	Bob Williams	2	2025-07-21	14:00:00	Scheduled
\.


--
-- TOC entry 4806 (class 0 OID 16401)
-- Dependencies: 218
-- Data for Name: counselors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.counselors (counselor_id, name, specialization, availability) FROM stdin;
1	John Doe	Mental Health	Mon-Fri 9AM-5PM
2	Jack Coetzee	Mental Health	Wed-Fri 9AM-5PM
3	John will	Mental Health	Thu-Fri 8AM-3PM
4	Jane Smith	Career Counseling	Mon-Wed 10AM-4PM
\.


--
-- TOC entry 4810 (class 0 OID 16422)
-- Dependencies: 222
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feedback (feedback_id, student_name, counselor_id, rating, comments) FROM stdin;
1	Alice Johnson	1	5	Great session, very helpful!
2	Bob Williams	2	4	Good advice, could be more engaging.
\.


--
-- TOC entry 4819 (class 0 OID 0)
-- Dependencies: 219
-- Name: appointments_appointment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.appointments_appointment_id_seq', 2, true);


--
-- TOC entry 4820 (class 0 OID 0)
-- Dependencies: 217
-- Name: counselors_counselor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.counselors_counselor_id_seq', 4, true);


--
-- TOC entry 4821 (class 0 OID 0)
-- Dependencies: 221
-- Name: feedback_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.feedback_feedback_id_seq', 2, true);


--
-- TOC entry 4655 (class 2606 OID 16415)
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (appointment_id);


--
-- TOC entry 4653 (class 2606 OID 16408)
-- Name: counselors counselors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.counselors
    ADD CONSTRAINT counselors_pkey PRIMARY KEY (counselor_id);


--
-- TOC entry 4657 (class 2606 OID 16430)
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (feedback_id);


--
-- TOC entry 4658 (class 2606 OID 16416)
-- Name: appointments appointments_counselor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_counselor_id_fkey FOREIGN KEY (counselor_id) REFERENCES public.counselors(counselor_id) ON DELETE CASCADE;


--
-- TOC entry 4659 (class 2606 OID 16431)
-- Name: feedback feedback_counselor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_counselor_id_fkey FOREIGN KEY (counselor_id) REFERENCES public.counselors(counselor_id) ON DELETE CASCADE;


-- Completed on 2025-07-15 20:50:23

--
-- PostgreSQL database dump complete
--

