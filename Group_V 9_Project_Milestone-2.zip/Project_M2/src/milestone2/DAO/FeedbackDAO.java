/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package milestone2.DAO;

import milestone2.Models.FeedBackM;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Jt
 */
public class FeedbackDAO {
    private final Connection conn;

    public FeedbackDAO(Connection conn) {
        this.conn = conn;
    }

    public void insert(FeedBackM feedback) throws SQLException {
        String sql = "INSERT INTO feedback (student_name, counselor_id, rating, comments) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, feedback.getStudentName());
            stmt.setInt(2, feedback.getCounselorId());
            stmt.setInt(3, feedback.getRating());
            stmt.setString(4, feedback.getComments());
            stmt.executeUpdate();
        }
    }

    public void update(FeedBackM feedback) throws SQLException {
        String sql = "UPDATE feedback SET student_name = ?, counselor_id = ?, rating = ?, comments = ? WHERE feedback_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, feedback.getStudentName());
            stmt.setInt(2, feedback.getCounselorId());
            stmt.setInt(3, feedback.getRating());
            stmt.setString(4, feedback.getComments());
            stmt.setInt(5, feedback.getId());
            stmt.executeUpdate();
        }
    }

    public void delete(int feedbackId) throws SQLException {
        String sql = "DELETE FROM feedback WHERE feedback_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, feedbackId);
            stmt.executeUpdate();
        }
    }

    public List<FeedBackM> getAll() throws SQLException {
        List<FeedBackM> list = new ArrayList<>();
        String sql = "SELECT * FROM feedback";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new FeedBackM(
                    rs.getInt("feedback_id"),
                    rs.getString("student_name"),
                    rs.getInt("counselor_id"),
                    rs.getInt("rating"),
                    rs.getString("comments")
                ));
            }
        }
        return list;
    }
}
