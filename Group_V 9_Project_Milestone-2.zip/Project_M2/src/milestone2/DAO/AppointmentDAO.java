/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package milestone2.DAO;

import milestone2.Models.Appointment;
import milestone2.Models.Counselor;
import java.sql.*;
import java.util.*;
/**
 *
 * @author Jt
 */
public class AppointmentDAO {
    private final Connection conn;

    public AppointmentDAO(Connection conn) {
        this.conn = conn;
    }

    public List<Appointment> getAllAppointments() throws SQLException {
        List<Appointment> list = new ArrayList<>();
        String sql = "SELECT a.student_name, c.counselor_id, c.name, a.appointment_date, a.appointment_time, a.status " +
                     "FROM appointments a JOIN counselors c ON a.counselor_id = c.counselor_id";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Counselor counselor = new Counselor(rs.getInt("counselor_id"), rs.getString("name"));
                Appointment a = new Appointment(
                    rs.getString("student_name"),
                    counselor,
                    rs.getDate("appointment_date"),
                    rs.getTime("appointment_time"),
                    rs.getString("status")
                );
                list.add(a);
            }
        }
        return list;
    }

    public void insert(Appointment a) throws SQLException {
        String sql = "INSERT INTO appointments (student_name, counselor_id, appointment_date, appointment_time, status) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, a.getStudentName());
            ps.setInt(2, a.getCounselor().getId());
            ps.setDate(3, a.getAppointmentDate());
            ps.setTime(4, a.getAppointmentTime());
            ps.setString(5, a.getStatus());
            ps.executeUpdate();
        }
    }

   public void delete(String studentName, java.sql.Date date) throws SQLException {
        String sql = "DELETE FROM appointments WHERE student_name = ? AND appointment_date = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, studentName);
            ps.setDate(2, date);
            ps.executeUpdate();
        }
    }

    public void update(Appointment a, String oldName, java.sql.Date oldDate) throws SQLException {
        String sql = "UPDATE appointments SET student_name = ?, counselor_id = ?, appointment_date = ?, appointment_time = ? " +
                     "WHERE student_name = ? AND appointment_date = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, a.getStudentName());
            ps.setInt(2, a.getCounselor().getId());
            ps.setDate(3, a.getAppointmentDate());
            ps.setTime(4, a.getAppointmentTime());
            ps.setString(5, oldName);
            ps.setDate(6, oldDate);
            ps.executeUpdate();
        }
    }
}
