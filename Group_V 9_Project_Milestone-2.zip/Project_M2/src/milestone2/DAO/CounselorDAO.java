/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package milestone2.DAO;

import milestone2.Models.Counselor;

import java.sql.*;
import java.util.*;
/**
 *
 * @author Jt
 */
public class CounselorDAO {
    private final Connection conn;

    public CounselorDAO(Connection conn) {
        this.conn = conn;
    }

    public List<Counselor> getAllCounselors() throws SQLException {
        List<Counselor> list = new ArrayList<>();
        String sql = "SELECT * FROM counselors";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new Counselor(rs.getInt("counselor_id"), rs.getString("name")));
            }
        }
        return list;
    }

    public int getCounselorIdByName(String name) throws SQLException {
        String sql = "SELECT counselor_id FROM counselors WHERE name = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt("counselor_id");
        }
        return -1;
    }
}
