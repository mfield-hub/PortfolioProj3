package milestone2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class DatabaseConnection {
    private static Connection Conn = null;
    private static final String URL = "jdbc:postgresql://localhost:5432/wellness_management_system";//jdbc:postgresql://localhost:5432/wellness_management_system
    private static final String USER = "postgres";
    private static final String PASSWORD = "King@wesome0210";//King@wesome0210

    public static Connection getConnection() throws SQLException {
        
         try {
           Class.forName("org.postgresql.Driver");
       } catch (ClassNotFoundException ex) {
           Logger.getLogger(DatabaseConnection.class.getName()).log(Level.SEVERE, null, ex);
       }

       try {
           Conn = DriverManager.getConnection(URL, USER, PASSWORD);

           JOptionPane.showMessageDialog(null, "Connected");

       } catch (SQLException ex) {
           Logger.getLogger(DatabaseConnection.class.getName()).log(Level.SEVERE, null, ex);
       }
        return Conn;
   }
    
       public static void main(String[] args) throws SQLException {
   DatabaseConnection connDatabase = new DatabaseConnection();
   connDatabase.getConnection();
   }
}
