/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package milestone2.Models;

/**
 *
 * @author Jt
 */
public class FeedBackM {
    private int id;
    private String studentName;
    private int counselorId;
    private int rating;
    private String comments;

    public FeedBackM(String studentName, int counselorId, int rating, String comments) {
        this.studentName = studentName;
        this.counselorId = counselorId;
        this.rating = rating;
        this.comments = comments;
    }

    public FeedBackM(int id, String studentName, int counselorId, int rating, String comments) {
        this.id = id;
        this.studentName = studentName;
        this.counselorId = counselorId;
        this.rating = rating;
        this.comments = comments;
    }

    public int getId() { return id; }
    public String getStudentName() { return studentName; }
    public int getCounselorId() { return counselorId; }
    public int getRating() { return rating; }
    public String getComments() { return comments; }

    public void setId(int id) { this.id = id; }
    public void setStudentName(String studentName) { this.studentName = studentName; }
    public void setCounselorId(int counselorId) { this.counselorId = counselorId; }
    public void setRating(int rating) { this.rating = rating; }
    public void setComments(String comments) { this.comments = comments; }
}
