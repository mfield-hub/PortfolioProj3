/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package milestone2.Models;

import java.sql.Date;
import java.sql.Time;
/**
 *
 * @author Jt
 */
public class Appointment {
    private String studentName;
    private Counselor counselor;
    private Date appointmentDate;
    private Time appointmentTime;
    private String status;

    public Appointment(String studentName, Counselor counselor, Date appointmentDate, Time appointmentTime, String status) {
        this.studentName = studentName;
        this.counselor = counselor;
        this.appointmentDate = appointmentDate;
        this.appointmentTime = appointmentTime;
        this.status = status;
    }

    public String getStudentName() {
        return studentName;
    }

    public Counselor getCounselor() {
        return counselor;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public Time getAppointmentTime() {
        return appointmentTime;
    }

    public String getStatus() {
        return status;
    }
}
