/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package milestone2.Models;

/**
 *
 * @author Jt
 */
public class Feedback {
    private int id;
    private String studentName;
    private int counselorId;
    private int rating;
    private String comments;

    public Feedback(int id, String studentName, int counselorId, int rating, String comments) {
        this.id = id;
        this.studentName = studentName;
        this.counselorId = counselorId;
        this.rating = rating;
        this.comments = comments;
    }

    public Feedback(String studentName, int counselorId, int rating, String comments) {
        this(-1, studentName, counselorId, rating, comments);
    }

    public int getId() { return id; }
    public String getStudentName() { return studentName; }
    public int getCounselorId() { return counselorId; }
    public int getRating() { return rating; }
    public String getComments() { return comments; }

    public void setId(int id) { this.id = id; }
}
