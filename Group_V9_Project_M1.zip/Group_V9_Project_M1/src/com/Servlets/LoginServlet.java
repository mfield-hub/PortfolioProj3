package com.example;

import java.io.IOException;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import org.mindrot.jbcrypt.BCrypt;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:postgresql://localhost:5432/your_db";
    private static final String DB_USER = "admin";
    private static final String DB_PASS = "1234";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email").trim();
        String password = request.getParameter("password");

        if (email.isEmpty() || password.isEmpty()) {
            response.sendRedirect("login.jsp");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
            Class.forName("org.postgresql.Driver");

            String sql = "SELECT name, password FROM users WHERE email = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, email);

                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        String storedHash = rs.getString("password");
                        String name = rs.getString("name");

                        // Verify password with BCrypt
                        if (BCrypt.checkpw(password, storedHash)) {
                            HttpSession session = request.getSession();
                            session.setAttribute("userName", name);
                            session.setMaxInactiveInterval(30 * 60); // 30 minutes
                            response.sendRedirect("dashboard.jsp");
                        } else {
                            response.sendRedirect("login.jsp");
                        }
                    } else {
                        response.sendRedirect("login.jsp");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("login.jsp");
        }
    }
    <!-- login.jsp -->
<form method="post" action="${pageContext.request.contextPath}/login">

}
